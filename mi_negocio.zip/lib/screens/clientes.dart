import 'package:flutter/material.dart';
import '../db.dart';

class ClientesScreen extends StatefulWidget {
  const ClientesScreen({super.key});

  @override
  State<ClientesScreen> createState() => _ClientesScreenState();
}

class _ClientesScreenState extends State<ClientesScreen> {
  List<Map<String, dynamic>> _items = [];

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async {
    final r = await Db.instance.clientes();
    if (mounted) setState(() => _items = r);
  }

  Future<void> _formulario([Map<String, dynamic>? c]) async {
    final nombre = TextEditingController(text: c?['nombre'] as String? ?? '');
    final tel = TextEditingController(text: c?['telefono'] as String? ?? '');
    final clave = GlobalKey<FormState>();

    final guardar = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(c == null ? 'Nuevo cliente' : 'Editar cliente'),
        content: Form(
          key: clave,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextFormField(
              controller: nombre,
              decoration: const InputDecoration(labelText: 'Nombre'),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Escribe el nombre' : null,
            ),
            TextFormField(
              controller: tel,
              decoration: const InputDecoration(labelText: 'Teléfono'),
              keyboardType: TextInputType.phone,
            ),
          ]),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancelar')),
          FilledButton(
              onPressed: () {
                if (clave.currentState!.validate()) Navigator.pop(ctx, true);
              },
              child: const Text('Guardar')),
        ],
      ),
    );

    if (guardar == true) {
      await Db.instance.guardarCliente(
          {'nombre': nombre.text.trim(), 'telefono': tel.text.trim()},
          id: c?['id'] as int?);
      _cargar();
    }
  }

  Future<void> _borrar(Map<String, dynamic> c) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Eliminar cliente'),
        content: Text('¿Eliminar a "${c['nombre']}"?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancelar')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Eliminar')),
        ],
      ),
    );
    if (ok == true) {
      await Db.instance.borrarCliente(c['id'] as int);
      _cargar();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Clientes')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _formulario(),
        child: const Icon(Icons.person_add),
      ),
      body: _items.isEmpty
          ? const Center(child: Text('No hay clientes. Toca + para agregar.'))
          : ListView.separated(
              itemCount: _items.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) {
                final c = _items[i];
                final tel = (c['telefono'] as String?) ?? '';
                return ListTile(
                  leading: const CircleAvatar(child: Icon(Icons.person)),
                  title: Text(c['nombre'] as String),
                  subtitle: tel.isEmpty ? null : Text(tel),
                  onTap: () => _formulario(c),
                  trailing: IconButton(
                    icon: const Icon(Icons.delete_outline),
                    onPressed: () => _borrar(c),
                  ),
                );
              },
            ),
    );
  }
}
