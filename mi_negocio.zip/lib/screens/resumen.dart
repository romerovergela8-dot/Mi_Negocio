import 'package:flutter/material.dart';
import '../db.dart';

class ResumenScreen extends StatefulWidget {
  const ResumenScreen({super.key});

  @override
  State<ResumenScreen> createState() => _ResumenScreenState();
}

class _ResumenScreenState extends State<ResumenScreen> {
  Map<String, double> _hoy = {};
  List<Map<String, dynamic>> _dias = [];
  List<Map<String, dynamic>> _bajo = [];
  bool _cargando = true;

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async {
    final h = await Db.instance.resumenDelDia(hoy());
    final d = await Db.instance.ventasPorDia(7);
    final b = await Db.instance.stockBajo();
    if (!mounted) return;
    setState(() {
      _hoy = h;
      _dias = d;
      _bajo = b;
      _cargando = false;
    });
  }

  Widget _tarjeta(String titulo, String valor, IconData icono, Color color) {
    return Expanded(
      child: Card(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(icono, color: color),
              const SizedBox(height: 8),
              Text(valor,
                  style: const TextStyle(
                      fontSize: 20, fontWeight: FontWeight.bold)),
              Text(titulo, style: const TextStyle(fontSize: 12)),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    if (_cargando) return const Center(child: CircularProgressIndicator());
    final neto = (_hoy['ganancia'] ?? 0) - (_hoy['gastos'] ?? 0);
    return RefreshIndicator(
      onRefresh: _cargar,
      child: ListView(
        padding: const EdgeInsets.all(12),
        children: [
          const Text('Resumen de hoy',
              style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
          const SizedBox(height: 8),
          Row(children: [
            _tarjeta('Ventas (${(_hoy['cantidad'] ?? 0).toInt()})',
                money(_hoy['ventas'] ?? 0), Icons.shopping_cart, Colors.blue),
            _tarjeta('Ganancia bruta', money(_hoy['ganancia'] ?? 0),
                Icons.trending_up, Colors.green),
          ]),
          Row(children: [
            _tarjeta('Gastos', money(_hoy['gastos'] ?? 0),
                Icons.money_off, Colors.orange),
            _tarjeta('Ganancia neta', money(neto), Icons.account_balance_wallet,
                neto >= 0 ? Colors.teal : Colors.red),
          ]),
          const SizedBox(height: 12),
          const Text('Últimos 7 días',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          if (_dias.isEmpty)
            const Padding(
              padding: EdgeInsets.all(12),
              child: Text('Aún no hay ventas registradas.'),
            ),
          for (final d in _dias)
            ListTile(
              dense: true,
              leading: const Icon(Icons.calendar_today, size: 18),
              title: Text(d['dia'] as String),
              subtitle: Text('${d['n']} venta(s)'),
              trailing: Text(money(d['total'] as num),
                  style: const TextStyle(fontWeight: FontWeight.bold)),
            ),
          const SizedBox(height: 12),
          const Text('Productos con poco stock',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          if (_bajo.isEmpty)
            const Padding(
              padding: EdgeInsets.all(12),
              child: Text('Todo el inventario está en orden.'),
            ),
          for (final p in _bajo)
            ListTile(
              dense: true,
              leading: const Icon(Icons.warning_amber, color: Colors.red),
              title: Text(p['nombre'] as String),
              trailing: Text('Quedan ${money(p['stock'] as num)}',
                  style: const TextStyle(color: Colors.red)),
            ),
        ],
      ),
    );
  }
}
