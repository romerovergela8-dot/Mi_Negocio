import 'package:flutter/material.dart';
import '../db.dart';

class VenderScreen extends StatefulWidget {
  const VenderScreen({super.key});

  @override
  State<VenderScreen> createState() => _VenderScreenState();
}

class _VenderScreenState extends State<VenderScreen> {
  final List<CartItem> _carrito = [];

  double get _total => _carrito.fold(0, (s, i) => s + i.subtotal);

  void _aviso(String msg) {
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(content: Text(msg)));
  }

  double _enCarrito(int id) => _carrito
      .where((i) => i.producto['id'] == id)
      .fold(0.0, (s, i) => s + i.cantidad);

  void _agregar(Map<String, dynamic> p) {
    final id = p['id'] as int;
    final stock = (p['stock'] as num).toDouble();
    if (_enCarrito(id) + 1 > stock) {
      _aviso('No hay más stock de "${p['nombre']}"');
      return;
    }
    setState(() {
      final existente = _carrito.where((i) => i.producto['id'] == id);
      if (existente.isNotEmpty) {
        existente.first.cantidad += 1;
      } else {
        _carrito.add(CartItem(p, 1));
      }
    });
  }

  void _cambiar(CartItem i, double delta) {
    final stock = (i.producto['stock'] as num).toDouble();
    final nueva = i.cantidad + delta;
    if (nueva > stock) {
      _aviso('No hay más stock de "${i.producto['nombre']}"');
      return;
    }
    setState(() {
      if (nueva <= 0) {
        _carrito.remove(i);
      } else {
        i.cantidad = nueva;
      }
    });
  }

  Future<void> _elegirProducto() async {
    final lista = await Db.instance.productos();
    if (!mounted) return;
    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) {
        String q = '';
        return StatefulBuilder(builder: (ctx, setM) {
          final filtrada = lista
              .where((p) => (p['nombre'] as String)
                  .toLowerCase()
                  .contains(q.toLowerCase()))
              .toList();
          return Padding(
            padding: EdgeInsets.only(
                bottom: MediaQuery.of(ctx).viewInsets.bottom),
            child: SizedBox(
              height: MediaQuery.of(ctx).size.height * 0.7,
              child: Column(children: [
                Padding(
                  padding: const EdgeInsets.all(8),
                  child: TextField(
                    autofocus: true,
                    decoration: const InputDecoration(
                        prefixIcon: Icon(Icons.search),
                        hintText: 'Buscar producto',
                        border: OutlineInputBorder()),
                    onChanged: (v) => setM(() => q = v),
                  ),
                ),
                Expanded(
                  child: filtrada.isEmpty
                      ? const Center(child: Text('Sin resultados'))
                      : ListView.builder(
                          itemCount: filtrada.length,
                          itemBuilder: (_, i) {
                            final p = filtrada[i];
                            final sinStock = (p['stock'] as num) <= 0;
                            return ListTile(
                              enabled: !sinStock,
                              title: Text(p['nombre'] as String),
                              subtitle: Text(
                                  'Stock ${money(p['stock'] as num)}'),
                              trailing: Text(money(p['precio'] as num),
                                  style: const TextStyle(
                                      fontWeight: FontWeight.bold)),
                              onTap: () {
                                _agregar(p);
                                Navigator.pop(ctx);
                              },
                            );
                          },
                        ),
                ),
              ]),
            ),
          );
        });
      },
    );
  }

  Future<void> _cobrar() async {
    if (_carrito.isEmpty) return;
    final clientes = await Db.instance.clientes();
    if (!mounted) return;
    int? clienteId;
    String metodo = 'Efectivo';

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setD) => AlertDialog(
          title: Text('Cobrar ${money(_total)}'),
          content: Column(mainAxisSize: MainAxisSize.min, children: [
            DropdownButtonFormField<int?>(
              value: clienteId,
              decoration: const InputDecoration(labelText: 'Cliente (opcional)'),
              items: [
                const DropdownMenuItem<int?>(
                    value: null, child: Text('Sin cliente')),
                for (final c in clientes)
                  DropdownMenuItem<int?>(
                      value: c['id'] as int, child: Text(c['nombre'] as String)),
              ],
              onChanged: (v) => setD(() => clienteId = v),
            ),
            DropdownButtonFormField<String>(
              value: metodo,
              decoration: const InputDecoration(labelText: 'Forma de pago'),
              items: const [
                DropdownMenuItem(value: 'Efectivo', child: Text('Efectivo')),
                DropdownMenuItem(
                    value: 'Transferencia', child: Text('Transferencia')),
                DropdownMenuItem(value: 'Otro', child: Text('Otro')),
              ],
              onChanged: (v) => setD(() => metodo = v ?? 'Efectivo'),
            ),
          ]),
          actions: [
            TextButton(
                onPressed: () => Navigator.pop(ctx, false),
                child: const Text('Cancelar')),
            FilledButton(
                onPressed: () => Navigator.pop(ctx, true),
                child: const Text('Confirmar venta')),
          ],
        ),
      ),
    );

    if (ok == true) {
      await Db.instance.registrarVenta(_carrito, clienteId, metodo);
      if (!mounted) return;
      setState(() => _carrito.clear());
      _aviso('Venta registrada');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Nueva venta')),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _elegirProducto,
        icon: const Icon(Icons.add_shopping_cart),
        label: const Text('Agregar producto'),
      ),
      body: _carrito.isEmpty
          ? const Center(
              child: Text('El carrito está vacío.\nToca "Agregar producto".',
                  textAlign: TextAlign.center))
          : ListView.builder(
              padding: const EdgeInsets.only(bottom: 90),
              itemCount: _carrito.length,
              itemBuilder: (_, i) {
                final it = _carrito[i];
                return ListTile(
                  title: Text(it.producto['nombre'] as String),
                  subtitle: Text(
                      '${money(it.precio)} x ${money(it.cantidad)} = ${money(it.subtotal)}'),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    IconButton(
                        icon: const Icon(Icons.remove_circle_outline),
                        onPressed: () => _cambiar(it, -1)),
                    IconButton(
                        icon: const Icon(Icons.add_circle_outline),
                        onPressed: () => _cambiar(it, 1)),
                  ]),
                );
              },
            ),
      bottomNavigationBar: _carrito.isEmpty
          ? null
          : Padding(
              padding: const EdgeInsets.all(12),
              child: FilledButton(
                style: FilledButton.styleFrom(
                    minimumSize: const Size.fromHeight(52)),
                onPressed: _cobrar,
                child: Text('Cobrar  ${money(_total)}',
                    style: const TextStyle(fontSize: 18)),
              ),
            ),
    );
  }
}
