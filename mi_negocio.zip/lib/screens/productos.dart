import 'package:flutter/material.dart';
import '../db.dart';

class ProductosScreen extends StatefulWidget {
  const ProductosScreen({super.key});

  @override
  State<ProductosScreen> createState() => _ProductosScreenState();
}

class _ProductosScreenState extends State<ProductosScreen> {
  List<Map<String, dynamic>> _items = [];
  String _q = '';

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async {
    final r = await Db.instance.productos(_q);
    if (mounted) setState(() => _items = r);
  }

  Future<void> _formulario([Map<String, dynamic>? p]) async {
    final nombre = TextEditingController(text: p?['nombre'] as String? ?? '');
    final precio = TextEditingController(text: p == null ? '' : '${p['precio']}');
    final costo = TextEditingController(text: p == null ? '' : '${p['costo']}');
    final stock = TextEditingController(text: p == null ? '' : '${p['stock']}');
    final minimo =
        TextEditingController(text: p == null ? '' : '${p['stock_minimo']}');
    final clave = GlobalKey<FormState>();

    String? numero(String? v) =>
        (v == null || v.trim().isEmpty || double.tryParse(v.replaceAll(',', '.')) != null)
            ? null
            : 'Número inválido';
    double n(TextEditingController c) =>
        double.tryParse(c.text.replaceAll(',', '.')) ?? 0;

    final guardar = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(p == null ? 'Nuevo producto' : 'Editar producto'),
        content: Form(
          key: clave,
          child: SingleChildScrollView(
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              TextFormField(
                controller: nombre,
                decoration: const InputDecoration(labelText: 'Nombre'),
                validator: (v) =>
                    (v == null || v.trim().isEmpty) ? 'Escribe el nombre' : null,
              ),
              TextFormField(
                controller: precio,
                decoration: const InputDecoration(labelText: 'Precio de venta'),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                validator: (v) => (v == null || v.trim().isEmpty)
                    ? 'Escribe el precio'
                    : numero(v),
              ),
              TextFormField(
                controller: costo,
                decoration: const InputDecoration(labelText: 'Costo (opcional)'),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                validator: numero,
              ),
              TextFormField(
                controller: stock,
                decoration: const InputDecoration(labelText: 'Stock actual'),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                validator: numero,
              ),
              TextFormField(
                controller: minimo,
                decoration:
                    const InputDecoration(labelText: 'Aviso de stock mínimo'),
                keyboardType: const TextInputType.numberWithOptions(decimal: true),
                validator: numero,
              ),
            ]),
          ),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancelar')),
          FilledButton(
              onPressed: () {
                if (clave.currentState!.validate()) Navigator.pop(ctx, true);
              },
              child: const Text('Guardar')),
        ],
      ),
    );

    if (guardar == true) {
      await Db.instance.guardarProducto({
        'nombre': nombre.text.trim(),
        'precio': n(precio),
        'costo': n(costo),
        'stock': n(stock),
        'stock_minimo': n(minimo),
      }, id: p?['id'] as int?);
      _cargar();
    }
  }

  Future<void> _borrar(Map<String, dynamic> p) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Eliminar producto'),
        content: Text('¿Eliminar "${p['nombre']}"?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancelar')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Eliminar')),
        ],
      ),
    );
    if (ok == true) {
      await Db.instance.borrarProducto(p['id'] as int);
      _cargar();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Productos')),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _formulario(),
        child: const Icon(Icons.add),
      ),
      body: Column(children: [
        Padding(
          padding: const EdgeInsets.all(8),
          child: TextField(
            decoration: const InputDecoration(
                prefixIcon: Icon(Icons.search),
                hintText: 'Buscar producto',
                border: OutlineInputBorder()),
            onChanged: (v) {
              _q = v;
              _cargar();
            },
          ),
        ),
        Expanded(
          child: _items.isEmpty
              ? const Center(child: Text('No hay productos. Toca + para agregar.'))
              : ListView.separated(
                  itemCount: _items.length,
                  separatorBuilder: (_, __) => const Divider(height: 1),
                  itemBuilder: (_, i) {
                    final p = _items[i];
                    final bajo =
                        (p['stock'] as num) <= (p['stock_minimo'] as num);
                    return ListTile(
                      title: Text(p['nombre'] as String),
                      subtitle: Text(
                          'Precio ${money(p['precio'] as num)}  •  Stock ${money(p['stock'] as num)}'),
                      leading: Icon(
                          bajo ? Icons.warning_amber : Icons.inventory_2,
                          color: bajo ? Colors.red : null),
                      onTap: () => _formulario(p),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () => _borrar(p),
                      ),
                    );
                  },
                ),
        ),
      ]),
    );
  }
}
