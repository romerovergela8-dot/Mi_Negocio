import 'package:flutter/material.dart';
import '../db.dart';

class GastosScreen extends StatefulWidget {
  const GastosScreen({super.key});

  @override
  State<GastosScreen> createState() => _GastosScreenState();
}

class _GastosScreenState extends State<GastosScreen> {
  List<Map<String, dynamic>> _items = [];

  @override
  void initState() {
    super.initState();
    _cargar();
  }

  Future<void> _cargar() async {
    final r = await Db.instance.gastos();
    if (mounted) setState(() => _items = r);
  }

  Future<void> _nuevo() async {
    final concepto = TextEditingController();
    final monto = TextEditingController();
    final clave = GlobalKey<FormState>();

    final guardar = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Nuevo gasto'),
        content: Form(
          key: clave,
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            TextFormField(
              controller: concepto,
              decoration: const InputDecoration(labelText: 'Concepto'),
              validator: (v) =>
                  (v == null || v.trim().isEmpty) ? 'Escribe el concepto' : null,
            ),
            TextFormField(
              controller: monto,
              decoration: const InputDecoration(labelText: 'Monto'),
              keyboardType: const TextInputType.numberWithOptions(decimal: true),
              validator: (v) =>
                  (double.tryParse((v ?? '').replaceAll(',', '.')) == null)
                      ? 'Monto inválido'
                      : null,
            ),
          ]),
        ),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancelar')),
          FilledButton(
              onPressed: () {
                if (clave.currentState!.validate()) Navigator.pop(ctx, true);
              },
              child: const Text('Guardar')),
        ],
      ),
    );

    if (guardar == true) {
      await Db.instance.guardarGasto(
          concepto.text.trim(), double.parse(monto.text.replaceAll(',', '.')));
      _cargar();
    }
  }

  Future<void> _borrar(Map<String, dynamic> g) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Eliminar gasto'),
        content: Text('¿Eliminar "${g['concepto']}"?'),
        actions: [
          TextButton(
              onPressed: () => Navigator.pop(ctx, false),
              child: const Text('Cancelar')),
          FilledButton(
              onPressed: () => Navigator.pop(ctx, true),
              child: const Text('Eliminar')),
        ],
      ),
    );
    if (ok == true) {
      await Db.instance.borrarGasto(g['id'] as int);
      _cargar();
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Gastos')),
      floatingActionButton: FloatingActionButton(
        onPressed: _nuevo,
        child: const Icon(Icons.add),
      ),
      body: _items.isEmpty
          ? const Center(child: Text('No hay gastos. Toca + para agregar.'))
          : ListView.separated(
              itemCount: _items.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (_, i) {
                final g = _items[i];
                final fecha = (g['fecha'] as String).substring(0, 10);
                return ListTile(
                  leading: const Icon(Icons.receipt_long),
                  title: Text(g['concepto'] as String),
                  subtitle: Text(fecha),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    Text(money(g['monto'] as num),
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () => _borrar(g),
                    ),
                  ]),
                );
              },
            ),
    );
  }
}
