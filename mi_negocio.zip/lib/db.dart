import 'package:intl/intl.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

/// Línea del carrito de venta.
class CartItem {
  final Map<String, dynamic> producto;
  double cantidad;
  CartItem(this.producto, this.cantidad);

  double get precio => (producto['precio'] as num).toDouble();
  double get costo => (producto['costo'] as num).toDouble();
  double get subtotal => precio * cantidad;
}

String money(num v) => NumberFormat('#,##0.00').format(v);
String hoy() => DateFormat('yyyy-MM-dd').format(DateTime.now());

class Db {
  static final Db instance = Db._();
  Db._();
  Database? _db;

  Future<Database> get database async => _db ??= await _open();

  Future<Database> _open() async {
    final path = join(await getDatabasesPath(), 'mi_negocio.db');
    return openDatabase(
      path,
      version: 1,
      onCreate: (db, v) async {
        await db.execute('''
          CREATE TABLE productos(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            precio REAL NOT NULL,
            costo REAL NOT NULL DEFAULT 0,
            stock REAL NOT NULL DEFAULT 0,
            stock_minimo REAL NOT NULL DEFAULT 0
          )''');
        await db.execute('''
          CREATE TABLE clientes(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            nombre TEXT NOT NULL,
            telefono TEXT
          )''');
        await db.execute('''
          CREATE TABLE ventas(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fecha TEXT NOT NULL,
            total REAL NOT NULL,
            cliente_id INTEGER,
            metodo TEXT
          )''');
        await db.execute('''
          CREATE TABLE venta_items(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            venta_id INTEGER NOT NULL,
            producto_id INTEGER,
            nombre TEXT NOT NULL,
            cantidad REAL NOT NULL,
            precio REAL NOT NULL,
            costo REAL NOT NULL
          )''');
        await db.execute('''
          CREATE TABLE gastos(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            fecha TEXT NOT NULL,
            concepto TEXT NOT NULL,
            monto REAL NOT NULL
          )''');
      },
    );
  }

  // ---------- Productos ----------
  Future<List<Map<String, dynamic>>> productos([String q = '']) async {
    final d = await database;
    return d.query('productos',
        where: q.isEmpty ? null : 'nombre LIKE ?',
        whereArgs: q.isEmpty ? null : ['%$q%'],
        orderBy: 'nombre COLLATE NOCASE');
  }

  Future<void> guardarProducto(Map<String, dynamic> p, {int? id}) async {
    final d = await database;
    if (id == null) {
      await d.insert('productos', p);
    } else {
      await d.update('productos', p, where: 'id = ?', whereArgs: [id]);
    }
  }

  Future<void> borrarProducto(int id) async {
    final d = await database;
    await d.delete('productos', where: 'id = ?', whereArgs: [id]);
  }

  Future<List<Map<String, dynamic>>> stockBajo() async {
    final d = await database;
    return d.query('productos',
        where: 'stock <= stock_minimo', orderBy: 'stock ASC');
  }

  // ---------- Clientes ----------
  Future<List<Map<String, dynamic>>> clientes() async {
    final d = await database;
    return d.query('clientes', orderBy: 'nombre COLLATE NOCASE');
  }

  Future<void> guardarCliente(Map<String, dynamic> c, {int? id}) async {
    final d = await database;
    if (id == null) {
      await d.insert('clientes', c);
    } else {
      await d.update('clientes', c, where: 'id = ?', whereArgs: [id]);
    }
  }

  Future<void> borrarCliente(int id) async {
    final d = await database;
    await d.delete('clientes', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- Gastos ----------
  Future<List<Map<String, dynamic>>> gastos() async {
    final d = await database;
    return d.query('gastos', orderBy: 'fecha DESC, id DESC', limit: 200);
  }

  Future<void> guardarGasto(String concepto, double monto) async {
    final d = await database;
    await d.insert('gastos', {
      'fecha': DateTime.now().toIso8601String(),
      'concepto': concepto,
      'monto': monto,
    });
  }

  Future<void> borrarGasto(int id) async {
    final d = await database;
    await d.delete('gastos', where: 'id = ?', whereArgs: [id]);
  }

  // ---------- Ventas ----------
  Future<void> registrarVenta(
      List<CartItem> items, int? clienteId, String metodo) async {
    final d = await database;
    await d.transaction((txn) async {
      final total = items.fold<double>(0, (s, i) => s + i.subtotal);
      final ventaId = await txn.insert('ventas', {
        'fecha': DateTime.now().toIso8601String(),
        'total': total,
        'cliente_id': clienteId,
        'metodo': metodo,
      });
      for (final i in items) {
        await txn.insert('venta_items', {
          'venta_id': ventaId,
          'producto_id': i.producto['id'],
          'nombre': i.producto['nombre'],
          'cantidad': i.cantidad,
          'precio': i.precio,
          'costo': i.costo,
        });
        await txn.rawUpdate(
            'UPDATE productos SET stock = stock - ? WHERE id = ?',
            [i.cantidad, i.producto['id']]);
      }
    });
  }

  // ---------- Reportes ----------
  Future<Map<String, double>> resumenDelDia(String dia) async {
    final d = await database;
    final v = await d.rawQuery(
        "SELECT COALESCE(SUM(total),0) AS t, COUNT(*) AS n FROM ventas WHERE substr(fecha,1,10)=?",
        [dia]);
    final g = await d.rawQuery(
        "SELECT COALESCE(SUM(i.cantidad*(i.precio-i.costo)),0) AS g FROM venta_items i JOIN ventas v ON v.id=i.venta_id WHERE substr(v.fecha,1,10)=?",
        [dia]);
    final e = await d.rawQuery(
        "SELECT COALESCE(SUM(monto),0) AS e FROM gastos WHERE substr(fecha,1,10)=?",
        [dia]);
    return {
      'ventas': (v.first['t'] as num).toDouble(),
      'cantidad': (v.first['n'] as num).toDouble(),
      'ganancia': (g.first['g'] as num).toDouble(),
      'gastos': (e.first['e'] as num).toDouble(),
    };
  }

  /// Ventas por día de los últimos [dias] días (más reciente primero).
  Future<List<Map<String, dynamic>>> ventasPorDia(int dias) async {
    final d = await database;
    final desde = DateFormat('yyyy-MM-dd')
        .format(DateTime.now().subtract(Duration(days: dias - 1)));
    return d.rawQuery(
        "SELECT substr(fecha,1,10) AS dia, SUM(total) AS total, COUNT(*) AS n FROM ventas WHERE substr(fecha,1,10) >= ? GROUP BY dia ORDER BY dia DESC",
        [desde]);
  }
}
