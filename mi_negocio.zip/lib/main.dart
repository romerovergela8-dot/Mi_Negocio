import 'package:flutter/material.dart';
import 'screens/clientes.dart';
import 'screens/gastos.dart';
import 'screens/productos.dart';
import 'screens/resumen.dart';
import 'screens/vender.dart';

void main() => runApp(const MiNegocioApp());

class MiNegocioApp extends StatelessWidget {
  const MiNegocioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Mi Negocio',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: const Color(0xFF1565C0),
      ),
      home: const Principal(),
    );
  }
}

class Principal extends StatefulWidget {
  const Principal({super.key});

  @override
  State<Principal> createState() => _PrincipalState();
}

class _PrincipalState extends State<Principal> {
  int _tab = 0;

  @override
  Widget build(BuildContext context) {
    // Se crea la pantalla de nuevo al cambiar de pestaña, así siempre
    // muestra datos actualizados.
    final pantallas = <Widget>[
      const ResumenScreen(),
      const VenderScreen(),
      const ProductosScreen(),
      const ClientesScreen(),
      const GastosScreen(),
    ];
    return Scaffold(
      body: SafeArea(child: pantallas[_tab]),
      bottomNavigationBar: NavigationBar(
        selectedIndex: _tab,
        onDestinationSelected: (i) => setState(() => _tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.dashboard_outlined), selectedIcon: Icon(Icons.dashboard), label: 'Resumen'),
          NavigationDestination(icon: Icon(Icons.point_of_sale_outlined), selectedIcon: Icon(Icons.point_of_sale), label: 'Vender'),
          NavigationDestination(icon: Icon(Icons.inventory_2_outlined), selectedIcon: Icon(Icons.inventory_2), label: 'Productos'),
          NavigationDestination(icon: Icon(Icons.people_outline), selectedIcon: Icon(Icons.people), label: 'Clientes'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Gastos'),
        ],
      ),
    );
  }
}
