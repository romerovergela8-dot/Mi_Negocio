# Cómo obtener el APK sin instalar nada en tu PC

1. Crea una cuenta gratis en https://github.com y un repositorio nuevo (por ejemplo "mi-negocio").
2. En el repositorio: "Add file" > "Upload files" y arrastra TODO el contenido de esta carpeta
   (lib, pubspec.yaml, README.md, etc.).
3. Verifica que exista el archivo `.github/workflows/build.yml`. Si no se subió
   (las carpetas que empiezan con punto a veces se omiten): "Add file" > "Create new file",
   escribe el nombre `.github/workflows/build.yml` y pega el contenido de `build.yml.txt`.
4. Ve a la pestaña "Actions" > "Generar APK" > "Run workflow". Tarda unos 5-8 minutos.
5. Al terminar, entra a esa ejecución y descarga "mi-negocio-apk" (viene en un zip con app-release.apk).
6. Pasa el APK al teléfono e instálalo (permite "instalar apps de orígenes desconocidos").
