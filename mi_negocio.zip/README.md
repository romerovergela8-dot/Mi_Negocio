# Mi Negocio (app Android con Flutter)

App para controlar tu negocio: **resumen del día, ventas, productos/inventario, clientes y gastos**.
Todo se guarda en el teléfono (SQLite), así que funciona sin internet.

## Cómo generar la app (una sola vez)

1. Instala Flutter: https://docs.flutter.dev/get-started/install (incluye Android Studio / SDK de Android).
2. Descomprime esta carpeta y ábrela en una terminal.
3. Genera los archivos de Android (esta carpeta solo trae el código):

   ```
   flutter create --platforms=android --project-name mi_negocio .
   flutter pub get
   ```

   Si `flutter create` pregunta por sobrescribir, no pasa nada: no toca `lib/` ni `pubspec.yaml` de forma destructiva. Si sí cambia `pubspec.yaml`, vuelve a poner las dependencias `sqflite`, `path` e `intl`.

4. Probar en un teléfono conectado por USB (con depuración USB activada) o en un emulador:

   ```
   flutter run
   ```

5. Generar el APK para instalarlo en cualquier teléfono:

   ```
   flutter build apk --release
   ```

   El archivo queda en `build/app/outputs/flutter-apk/app-release.apk`.

## Qué incluye

- **Resumen**: ventas, ganancia bruta, gastos y ganancia neta de hoy; ventas de los últimos 7 días; productos con poco stock.
- **Vender**: carrito, búsqueda de producto, cliente opcional, forma de pago. Al confirmar descuenta el stock automáticamente.
- **Productos**: alta, edición, baja, precio, costo, stock y aviso de stock mínimo.
- **Clientes**: alta, edición y baja.
- **Gastos**: registro de gastos con concepto y monto.

## Estructura

- `lib/db.dart`: base de datos SQLite y consultas de reportes.
- `lib/main.dart`: navegación inferior.
- `lib/screens/`: una pantalla por módulo.
